#!/bin/bash
emerge -e @world --exclude sys-devel/gcc --quiet
