#!/bin/bash
dbus-launch --exit-with-session pcmanfm
