#!/bin/bash
brightnessctl set 20%-
